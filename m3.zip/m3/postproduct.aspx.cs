﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class postproduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void postProduct(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("postProduct", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string vendorname = (string)(Session["currentuser"]);
            string productname = productn.Text;
            string category = pcategory.Text;
            string des = description.Text;
            string pcolor = color.Text;
            string pprice = price.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@vendorUsername", vendorname));
            cmd.Parameters.Add(new SqlParameter("@product_name", productname));
            cmd.Parameters.Add(new SqlParameter("@category", category));
            cmd.Parameters.Add(new SqlParameter("@product_description", des));
            cmd.Parameters.Add(new SqlParameter("@price", pprice));
            cmd.Parameters.Add(new SqlParameter("@color", pcolor));



            if (string.IsNullOrWhiteSpace(productname) || string.IsNullOrWhiteSpace(category) || string.IsNullOrWhiteSpace(des) || string.IsNullOrWhiteSpace(pprice) || string.IsNullOrWhiteSpace(pcolor))
            {
                Response.Write("Please re-enter all of the input");

            }
            else
            {
                try
                {

                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Successfully Posted!");
                }
                catch
                {
                    Response.Write("Incorrect Input!");
                }
            }
        }
    }
}