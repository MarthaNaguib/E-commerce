﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class EditProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        bool mineornot(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("myproduct", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            int serial = int.Parse(eserial.Text);
            string vendorname = (string)(Session["currentuser"]);

            cmd.Parameters.Add(new SqlParameter("@serial", (int)serial));
            cmd.Parameters.Add(new SqlParameter("@vendor", vendorname));
            //Save the output from the procedure
            SqlParameter mine = cmd.Parameters.Add("@mine", SqlDbType.Int);
            mine.Direction = ParameterDirection.Output;


            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();


            if (mine.Value.ToString().Equals("1"))
            {
                //To send response data to the client side (HTML)
                return true;


            }
            else
            {
                return false;
            }




        }

        protected void EditProduct(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("EditProduct", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string currentvendorname = (string)(Session["currentuser"]);


            try { 

            int serial = int.Parse(eserial.Text);
            string pname = eproductname.Text;
            string category = ecategory.Text;
            string des = edes.Text;
            string color = ecolor.Text;
            decimal price = 0;
            decimal.TryParse(eprice.Text, out price);



            // try
            // {
            if (serial == null)
            {
                Response.Write("Woops Couldn't Update missing Serial no");

            }
            else
            {



                    //still haven't tryed try and catch bas when i don't change in an object it turns it's value white



                    if (string.IsNullOrWhiteSpace(pname) && string.IsNullOrWhiteSpace(category) && string.IsNullOrWhiteSpace(des) && price == null && string.IsNullOrWhiteSpace(color))
                    {
                        Response.Write("At Least enter one input");

                    }
                    else
                    {


                        //pass parameters to the stored procedure
                        cmd.Parameters.Add(new SqlParameter("@vendorname", currentvendorname));
                        cmd.Parameters.Add(new SqlParameter("@serialnumber", (int)serial));
                        if (!eproductname.Text.Equals(""))
                        {
                            cmd.Parameters.Add(new SqlParameter("@product_name", pname));
                        }
                        else
                        {
                            cmd.Parameters.Add(new SqlParameter("@product_name", DBNull.Value));

                        }
                        if (!ecategory.Text.Equals(""))
                        {
                            cmd.Parameters.Add(new SqlParameter("@category", category));
                        }
                        else
                        {
                            cmd.Parameters.Add(new SqlParameter("@category", DBNull.Value));
                        }
                        if (!edes.Text.Equals(""))
                        {
                            cmd.Parameters.Add(new SqlParameter("@product_description", des));
                        }
                        else
                        {
                            cmd.Parameters.Add(new SqlParameter("@product_description", DBNull.Value));
                        }
                        if (!eprice.Text.Equals(""))
                        {
                            cmd.Parameters.Add(new SqlParameter("@price", (decimal)price));

                        }
                        else
                        {
                            cmd.Parameters.Add(new SqlParameter("@price", DBNull.Value));
                        }

                        if (!ecolor.Text.Equals(""))
                        {
                            cmd.Parameters.Add(new SqlParameter("@color", color));

                        }
                        else
                        {
                            cmd.Parameters.Add(new SqlParameter("@color", DBNull.Value));
                        }


                        //Executing the SQLCommand
                        conn.Open();
                        int a = cmd.ExecuteNonQuery();
                        conn.Close();

                        if (a <= 0)
                        {
                            Response.Write("Cannot Edit this offer. It is either not your product or some data is missing");

                        }
                        else
                        {
                            Response.Write("Successfully Updated!");
                        }
                    }


                    // Response.Write(category);

                }
            }
            catch
            {
                Response.Write("Woops Couldn't Update missing Serial no");

            }
            //  }

            // catch
            //  {
            //  Response.Write("FAILED ! Serial no not found");
        }// }



    }
}

