﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void activateVendors(object sender, EventArgs e)
        {

            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("activateVendors", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string vendorusername = namevendor.Text;


            //this is how you retrive data from session variable.
            string adminname = (string)(Session["currentuser"]);





            if (string.IsNullOrWhiteSpace(vendorusername))
            {
                Response.Write("Re-enter the vendor's name");
            }
            //pass parameters to the stored procedure
            else
            {
                cmd.Parameters.Add(new SqlParameter("@vendor_username", vendorusername));
                cmd.Parameters.Add(new SqlParameter("@admin_username", adminname));

                //Executing the SQLCommand
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    int a = cmd.ExecuteNonQuery();
                    conn.Close();
                    if (a == 0)
                    {
                        Response.Write("Vendor does not exist!");
                    }
                    else { Response.Write("Vendor Activated!"); }
                }
                catch
                {
                    Response.Write("Vendor is not correct!");
                }

            }

        }

        protected void reviewOrders(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("reviewOrders", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            conn.Open();

            //IF the output is a table, then we can read the records one at a time
            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            if (rdr.HasRows)
            {

                while (rdr.Read())
                {
                    //Get the value of the attribute name in the Company table
                    int order_no = rdr.GetInt32(0);
                    String order_date = (Convert.ToString(rdr["order_date"]));
                    String total_amount = (Convert.ToString(rdr["total_amount"]));
                    String cash_amount = (Convert.ToString(rdr["cash_amount"]));
                    String credit_amount = (Convert.ToString(rdr["credit_amount"]));
                    String payment_type = (Convert.ToString(rdr["payment_type"]));
                    String order_status = (Convert.ToString(rdr["order_status"]));
                    String remaining_days = (Convert.ToString(rdr["remaining_days"]));
                    String time_limit = (Convert.ToString(rdr["time_limit"]));
                    String Gift_Card_code_used = (Convert.ToString(rdr["Gift_Card_code_used"]));
                    String customer_name = rdr.GetString(rdr.GetOrdinal("customer_name"));
                    String delivery_id = (Convert.ToString(rdr["delivery_id"]));
                    String creditCard_number = (Convert.ToString(rdr["creditCard_number"]));
                    if (total_amount.Length == 0)
                        total_amount = "none";
                    if (cash_amount.Length == 0)
                        cash_amount = "none";
                    if (credit_amount.Length == 0)
                        credit_amount = "none";
                    if (payment_type.Length == 0)
                        payment_type = "none";
                    if (order_status.Length == 0)
                        order_status = "null";
                    if (remaining_days.Length == 0)
                        remaining_days = "none";
                    if (time_limit.Length == 0)
                        time_limit = "none";
                    if (Gift_Card_code_used.Length == 0)
                        Gift_Card_code_used = "none";
                    if (customer_name.Length == 0)
                        customer_name = "none";
                    if (delivery_id.Length == 0)
                        delivery_id = "none";
                    if (creditCard_number.Length == 0)
                        creditCard_number = "none";


















                    Label lbl_order_no = new Label();
                    lbl_order_no.Text = "order_no=" + order_no.ToString();
                    form1.Controls.Add(lbl_order_no);

                    Label lbl_order_date = new Label();
                    lbl_order_date.Text = "  ,order_date=" + order_date;
                    form1.Controls.Add(lbl_order_date);

                    Label lbl_total_amount = new Label();
                    lbl_total_amount.Text = "  ,total_amount=" + total_amount;
                    form1.Controls.Add(lbl_total_amount);

                    Label lbl_cash_amount = new Label();
                    lbl_cash_amount.Text = "  ,cash_amount=" + cash_amount;
                    form1.Controls.Add(lbl_cash_amount);


                    Label lbl_credit_amount = new Label();
                    lbl_credit_amount.Text = "  ,credit_amount=" + credit_amount;
                    form1.Controls.Add(lbl_credit_amount);


                    Label lbl_payment_type = new Label();
                    lbl_payment_type.Text = "  ,payment_type=" + payment_type;
                    form1.Controls.Add(lbl_payment_type);

                    Label lbl_order_status = new Label();
                    lbl_order_status.Text = "  ,order_status=" + order_status;
                    form1.Controls.Add(lbl_order_status);

                    Label lbl_remaining_days = new Label();
                    lbl_remaining_days.Text = "  ,remaining_days=" + remaining_days;
                    form1.Controls.Add(lbl_remaining_days);

                    Label lbl_time_limit = new Label();
                    lbl_time_limit.Text = "  ,time_limit=" + time_limit;
                    form1.Controls.Add(lbl_time_limit);

                    Label lbl_Gift_Card_code_used = new Label();
                    lbl_Gift_Card_code_used.Text = "  ,Gift_Card_Code=" + Gift_Card_code_used;
                    form1.Controls.Add(lbl_Gift_Card_code_used);




                    Label lbl_customer_name = new Label();
                    lbl_customer_name.Text = "  ,customer_name=" + customer_name;
                    form1.Controls.Add(lbl_customer_name);


                    Label lbl_delivery_id = new Label();
                    lbl_delivery_id.Text = "  ,delivery_id=" + delivery_id.ToString();
                    form1.Controls.Add(lbl_delivery_id);


                    Label lbl_creditCard_number = new Label();
                    lbl_creditCard_number.Text = "  ,creditCard_number=" + creditCard_number + "  <br /> <br />";
                    form1.Controls.Add(lbl_creditCard_number);





                }
            }
            else
            {
                Response.Write("No orders found!");
            }
            rdr.Close();
        }

        protected void updateOrderStatusInProcess(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("updateOrderStatusInProcess", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string order_no = orderno.Text;


            //this is how you retrive data from session variable.





            if (string.IsNullOrWhiteSpace(order_no))
            {
                Response.Write("Re-enter the order's number");
            }
            //pass parameters to the stored procedure
            else
            {
                cmd.Parameters.Add(new SqlParameter("@order_no", order_no));
                try
                {
                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    int a = cmd.ExecuteNonQuery();
                    conn.Close();

                    if (a == 0)
                    {
                        Response.Write("Order does not exist!");
                    }
                    else { Response.Write("Order Updated!"); }
                }
                catch
                {
                    Response.Write("Order is not correct!");
                }


            }

        }

        protected void createTodaysDeal(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("createTodaysDeal", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string deal_amount = dealamount.Text;
            string expiry_date = expdate.Text;


            //this is how you retrive data from session variable.
            string adminname = (string)(Session["currentuser"]);





            if (string.IsNullOrWhiteSpace(deal_amount) || string.IsNullOrWhiteSpace(expiry_date))
            {
                Response.Write("Please re-enter the data");
            }
            //pass parameters to the stored procedure
            else
            {
                cmd.Parameters.Add(new SqlParameter("@deal_amount", deal_amount));
                cmd.Parameters.Add(new SqlParameter("@admin_username", adminname));
                cmd.Parameters.Add(new SqlParameter("@expiry_date", expiry_date));


                try
                {
                    //Executing the SQLCommand
                    conn.Open();
                    //cmd.ExecuteNonQuery();
                    int a = cmd.ExecuteNonQuery();
                    conn.Close();
                    if (a == 0)
                    {
                        Response.Write("Please Re-create the deal!");
                    }
                    else { Response.Write("Deal created!"); }
                }
                catch
                {
                    Response.Write("Please write the date in the form '2018 / 4 / 5'");
                }

            }

        }

        protected void addTodaysDealOnProduct(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);
            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("addTodaysDealOnProduct", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //To read the input from the user
            string deal_id = dealid.Text;
            string serial_no = prodno.Text;
            if (string.IsNullOrWhiteSpace(deal_id) || string.IsNullOrWhiteSpace(serial_no))
            {
                Response.Write("Please re-enter the data");
            }
            //pass parameters to the stored procedure
            else
            {
                try
                {
                    cmd.Parameters.Add(new SqlParameter("@deal_id", deal_id));
                    cmd.Parameters.Add(new SqlParameter("@serial_no", serial_no));
                    //Executing the SQLCommand

                    conn.Open();

                    int a = cmd.ExecuteNonQuery();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    if (a <= 0)
                    {
                        //Response.Write("This deal is expired or incorrect!");
                        SqlCommand cmd2 = new SqlCommand("checkTodaysDealOnProduct", conn);
                        cmd2.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd2.Parameters.Add(new SqlParameter("@serial_no", serial_no));
                        SqlParameter active = cmd2.Parameters.Add("@activeDeal", SqlDbType.Bit);
                        active.Direction = ParameterDirection.Output;
                        conn.Open();
                        cmd2.ExecuteNonQuery();
                        conn.Close();
                        // Response.Write(active.Value);
                        if ((bool)active.Value)
                            Response.Write("This product has an active deal!");
                        else
                        {
                            Response.Write("This deal or product are not correct!");
                        }
                    }

                    else { Response.Write("Deal added!"); }
                }
                catch
                {
                    Response.Write("Deal not correct!");
                }

            }
        }

        protected void removeExpiredDeal(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("removeExpiredDeal", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string deal_id = dealidtoremove.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@deal_iD", deal_id));


            if (string.IsNullOrWhiteSpace(deal_id))
            {
                Response.Write("Please re-enter deal_id");

            }
            else
            {

                try
                {

                    //Executing the SQLCommand
                    conn.Open();
                    int a = cmd.ExecuteNonQuery();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    if (a <= 0)
                    {
                        Response.Write("This deal is not expired or does not exist");
                    }
                    else
                    {
                        Response.Write("Deal Removed");
                    }

                }
                catch
                {
                    Response.Write("Deal is Incorrect");
                }


            }



        }

    }
}