﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class makeorder : System.Web.UI.Page
    {
        public Label ProductName { get; private set; }

        public void Page_Load(object sender, EventArgs e)
        {
          
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("viewMyCart", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            // this is how you retrive data from session variable.
            string currentuser = (string)(Session["currentuser"]);
            //Response.Write(field1);
            cmd.Parameters.Add(new SqlParameter("@customer", currentuser));
            SqlCommand cmd1 = new SqlCommand("calculatepriceOrder", conn);
            cmd1.CommandType = CommandType.StoredProcedure;


            //Response.Write(field1);
            cmd1.Parameters.Add(new SqlParameter("@customername", currentuser));



            SqlParameter sum = cmd1.Parameters.Add("@sum", SqlDbType.Float);
            sum.Direction = ParameterDirection.Output;
            // cmd1.Parameters["@sum"].Value = s;

          double s = 0.0;
            conn.Open();
            cmd1.ExecuteNonQuery();
            try
            {
               
                s = Convert.ToDouble(cmd1.Parameters["@sum"].Value);
            }
            catch
            {
                s = 0.0;
            }






            //IF the output is a table, then we can read the records one at a time
            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            

            while (rdr.Read())
            {


                string productName = rdr.GetString(rdr.GetOrdinal("product_name"));

                string product_descriptipon = rdr.GetString(rdr.GetOrdinal("product_description"));

                decimal finalPrice = rdr.GetDecimal(rdr.GetOrdinal("final_price"));

                decimal price = rdr.GetDecimal(rdr.GetOrdinal("price"));

                string color = rdr.GetString(rdr.GetOrdinal("color"));




                //Create a new label and add it to the HTML form
                Label lbl_ProductName = new Label();
                lbl_ProductName.Text = "- " + productName + " ";
                form1.Controls.Add(lbl_ProductName);

                Label lbl_ProductDescription = new Label();
                lbl_ProductDescription.Text = product_descriptipon + "  <br /> <br />";
                form1.Controls.Add(lbl_ProductDescription);

                Label lbl_Color = new Label();
                lbl_Color.Text = "  Color: " + color + "  <br /> <br />";
                form1.Controls.Add(lbl_Color);

                Label lbl_Price = new Label();
                lbl_Price.Text = "  Price: " + price + "  <br /> <br />";
                form1.Controls.Add(lbl_Price);

                Label lbl_FinalPrice = new Label();
                lbl_FinalPrice.Text = "    Final Price:  " + finalPrice + "  <br /> <br />";
                form1.Controls.Add(lbl_FinalPrice);

                

            }

            if (s > 0)
            {
                Label lbl_sum = new Label();
                lbl_sum.Text = " Total amount:  " + s + "  <br /> <br />";
                lbl_sum.ForeColor = System.Drawing.Color.Red;
                form1.Controls.Add(lbl_sum);

            }
           


        }



        public  int orderid()
        {


            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("reviewOrders", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            cmd.ExecuteNonQuery();
           
            SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);


            int take = 0;
            
           
          

            while (rdr.Read())
            {

                int orderID = rdr.GetInt32(rdr.GetOrdinal("order_no"));
                take = orderID;


            }
            
            Label lbl_orderid= new Label();
            lbl_orderid.Text = " Order ID :  " + take + "  <br /> <br />";
            lbl_orderid.ForeColor = System.Drawing.Color.Red;
            form1.Controls.Add(lbl_orderid);

            return take;




        }


        public void makeOrder(object sender, EventArgs e)
        {

           
            
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

           

            // this is how you retrive data from session variable.
            string currentuser = (string)(Session["currentuser"]);


            SqlCommand cmd1 = new SqlCommand("calculatepriceOrder", conn);
            cmd1.CommandType = CommandType.StoredProcedure;


            //Response.Write(field1);
            cmd1.Parameters.Add(new SqlParameter("@customername", currentuser));
            
            String cas =cash.Text;
            String cred  = credit.Text;
            String crednum = creditnum.Text;

            Double cass = 0.0;
            Double credd = 0.0;

            


            SqlParameter sum = cmd1.Parameters.Add("@sum", SqlDbType.Float);
            sum.Direction = ParameterDirection.Output;
            // cmd1.Parameters["@sum"].Value = s;

            double s = 0.0;
            conn.Open();
            cmd1.ExecuteNonQuery();
            try
            {
                // read output value from @NewId
                s = Convert.ToDouble(cmd1.Parameters["@sum"].Value);
              


            }
            catch
            {
                s = 0.0;
               

            }

           



            if (s > 0)
            {
                if (String.IsNullOrWhiteSpace(cas) && String.IsNullOrWhiteSpace(cred))
                {
                    Response.Write("PLease specify your payment method");
                }
                else if (!String.IsNullOrWhiteSpace(cas) && !String.IsNullOrWhiteSpace(cred))
                {
                    Response.Write("PLease specify only one payment method");
                }

                else if (String.IsNullOrWhiteSpace(crednum) && !String.IsNullOrWhiteSpace(cred))
                {
                    Response.Write("please write your Credit Card Number");
                }
              


                else {

                    if (!String.IsNullOrWhiteSpace(cas))
                    {

                       cass = Convert.ToDouble(cash.Text);
                       
                    }


                    else if (!String.IsNullOrWhiteSpace(cred)) {

                       credd = Convert.ToDouble(credit.Text);
                       
                    }


                    

                    SqlCommand cmd = new SqlCommand("makeOrder", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    

                    Response.Write("Successful Order!");
                    cmd.Parameters.Add(new SqlParameter("@customername", currentuser));
                    cmd.ExecuteNonQuery();

                   


                    SqlCommand cmd2 = new SqlCommand("emptyCart", conn);
                    cmd2.CommandType = CommandType.StoredProcedure;

                 

                    //Response.Write(field1);
                    cmd2.Parameters.Add(new SqlParameter("@customername", currentuser));
                    cmd2.ExecuteNonQuery();
                  //  Page_Load(null, null);

                    int id = orderid();

                    Label lbl_sum = new Label();
                    lbl_sum.Text = " Order amount:  " + s + "  <br /> <br />";
                    lbl_sum.ForeColor = System.Drawing.Color.Red;
                    form1.Controls.Add(lbl_sum);




                    SqlCommand cmd3 = new SqlCommand("SpecifyAmount", conn);
                    cmd3.CommandType = CommandType.StoredProcedure;


                    //Response.Write(field1);
                    cmd3.Parameters.Add(new SqlParameter("@customername", currentuser));
                    cmd3.Parameters.Add(new SqlParameter("@orderID", id));
                    cmd3.Parameters.Add(new SqlParameter("@cash", cass));
                    cmd3.Parameters.Add(new SqlParameter("@credit", credd));

                    
                    
                    cmd3.ExecuteNonQuery();
                    

                    if (String.IsNullOrWhiteSpace(cas) && !String.IsNullOrWhiteSpace(crednum) && !String.IsNullOrWhiteSpace(cred))
                        {
                        //he pays in credit



                        SqlCommand cmd4 = new SqlCommand("ChooseCreditCard", conn);
                        cmd4.CommandType = CommandType.StoredProcedure;


                        //Response.Write(field1);
                        cmd4.Parameters.Add(new SqlParameter("@creditcard", crednum));
                        cmd4.Parameters.Add(new SqlParameter("@orderid", id));
                        try { cmd4.ExecuteNonQuery(); }
                        catch { Response.Write("Invalid Credit Card number!"); }
                      

                    }






                    //conn.Open();
                    
                    conn.Close();
               
                }


            }
            else
            {
                Response.Write("Your Cart is Empty,Please add products to your cart first!");
            }





           


           
           








           



        }

    

       

        protected void cancelorder(object sender, EventArgs e)
       {


            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string currentuser = (string)(Session["currentuser"]);


            

            String orderID = cancel.Text;

            conn.Open();




            bool b = false;
            bool found = false;


            if (string.IsNullOrWhiteSpace(orderID))
            {
                Response.Write("please enter the orderID of the order you want to cancel");
            }

            else
            {
                SqlCommand cmd5= new SqlCommand("reviewOrders", conn);
                cmd5.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd5.ExecuteReader(CommandBehavior.CloseConnection);
                //conn.Open();
               // cmd5.ExecuteNonQuery();

                while (rdr.Read())
                {
                    string customerName = rdr.GetString(rdr.GetOrdinal("customer_name"));
                    string status = rdr.GetString(rdr.GetOrdinal("order_status"));
                    int iid = rdr.GetInt32(rdr.GetOrdinal("order_no"));
                    string id = Convert.ToString(iid);


                    if (id.Equals(orderID)){

                        found = true;

                        if (customerName.Equals(currentuser) && (status.Equals("not processed") || status.Equals("in process")))
                        {

                            b = true;



                        }

                        else if (status.Equals("delivered"))
                        {
                            Response.Write("This order has been delivered, it can't be cancelled");
                        }

                        else if (!customerName.Equals(currentuser))
                        {

                            Response.Write("You have no order with this orderID");

                        }





                    }


           }
                conn.Close();

                if (b == true)
                {

                    SqlCommand cmd = new SqlCommand("cancelOrder", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@orderid", orderID));
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Your Order has been cancelled!");
                }
                else if (found == false)
                {
                    Response.Write("Invalid orderID");
                }


            }


         
        }
    }
    
}