﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class offerapply : System.Web.UI.Page
    {




        protected void Page_Load(object sender, EventArgs e)
        {

        }


        bool check(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("checkOfferonProduct", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            int serial = int.Parse(applyserial.Text);


            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@serial", (int)serial));

            //Save the output from the procedure
            SqlParameter active = cmd.Parameters.Add("@activeoffer", SqlDbType.Int);
            active.Direction = ParameterDirection.Output;


            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();


            if (active.Value.ToString().Equals("1"))
            {
                //To send response data to the client side (HTML)
                return true;


            }
            else
            {
                return false;
            }
        }

        protected void applyOffer(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("applyOffer", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string vendorname = (string)(Session["currentuser"]);
            try
            {
                int serial = int.Parse(applyserial.Text);
                int offerid = int.Parse(offerId.Text);

                //pass parameters to the stored procedure



                if (serial == null || offerid == null)
                {
                    Response.Write("Please re-enter all of the input");

                }
                else
                {

                    bool act = check(sender, e);
                    if (act == true)
                    {
                        Response.Write("This product already has an active offer on it");

                    }
                    else
                    {
                        try
                        {

                            cmd.Parameters.Add(new SqlParameter("@vendorname", vendorname));
                            cmd.Parameters.Add(new SqlParameter("@offerid", (int)offerid));
                            cmd.Parameters.Add(new SqlParameter("@serial", (int)serial));

                            //Executing the SQLCommand
                            conn.Open();

                            int a = cmd.ExecuteNonQuery();
                            conn.Close();
                            if (a <= 0)
                            {
                                Response.Write("You are applying an Incorrect or Expired offer or to a wrong product");

                            }
                            else
                            {
                                Response.Write("APPLIED SUCCESSFULLY!");
                            }

                        }
                        catch
                        {
                            Response.Write("try again");
                        }

                    }



                }
            }
            catch
            {
                Response.Write("try again");

            }
        }

    }
}