﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class register : System.Web.UI.Page
    {
        public object RegisterUser { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {

           

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {


        }

        protected void rmail_TextChanged(object sender, EventArgs e)
        {

        }

        protected void rusername_TextChanged(object sender, EventArgs e)
        {

        }



        protected void customerRegister(object sender, EventArgs e)
        {

            // FormsAuthentication.SetAuthCookie(cusername.Text, false /* createPersistentCookie */);

            //string continueUrl = RegisterUser.ContinueDestinationPageUrl;
            //if (String.IsNullOrEmpty(continueUrl))
            //{
            //    continueUrl = "~/";
            //}
            //Response.Redirect(continueUrl);

            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("customerRegister", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string username = cusername.Text;
            string firstname = cfname.Text;
            string lastname = clname.Text;
            string email = cmail.Text;
            string password = cpass.Text;




            try
            {

                if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(firstname) || string.IsNullOrWhiteSpace(lastname) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                {
                    Response.Write("Please re-enter all of the inputs");
                }
                //pass parameters to the stored procedure
                else
                {
                    cmd.Parameters.Add(new SqlParameter("@username", username));
                    cmd.Parameters.Add(new SqlParameter("@password", password));
                    cmd.Parameters.Add(new SqlParameter("@first_name", firstname));
                    cmd.Parameters.Add(new SqlParameter("@last_name", lastname));
                    cmd.Parameters.Add(new SqlParameter("@email", email));
                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    Response.Write("Successfully Registered!");

                }

            }
            catch
            {
                Response.Write("This username in taken, please choose another one");
            }
           

           
            



        }

        protected void User_(object sender, EventArgs e)
        {

        }

        protected void User_mobile_numbers(object sender, EventArgs e)
        {



            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection

            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("addMobile", conn);

            cmd.CommandType = System.Data.CommandType.StoredProcedure;



            string user = cusername.Text;
            string mobile = cmobile.Text;

            try
            {
                
   
                if (string.IsNullOrWhiteSpace(mobile))
                {
                    Response.Write("Please enter your Mobile number if you want to add it.");


                }
                else
                {


                    cmd.Parameters.Add(new SqlParameter("@username", user));
                    cmd.Parameters.Add(new SqlParameter("@mobile_number", mobile));
                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                Response.Write("Telephone Number added!");

            }
            }
            catch
            {
                Response.Write("Please Register successfully first.");

            }







        }

        protected void clogin(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }

}
