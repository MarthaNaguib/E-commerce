﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void userLogin(object sender, EventArgs e)
        {
            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("userLogin", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user
            string username = lusername.Text;
            string password = lpass.Text;

            //pass parameters to the stored procedure
            cmd.Parameters.Add(new SqlParameter("@username", username));
            cmd.Parameters.Add(new SqlParameter("@password", password));


            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Response.Write("Please re-enter all of the input");

            }
            else {


                //Save the output from the procedure
                SqlParameter success = cmd.Parameters.Add("@success", SqlDbType.Int);
                success.Direction = ParameterDirection.Output;



                SqlParameter type = cmd.Parameters.Add("@type", SqlDbType.Int);
                type.Direction = ParameterDirection.Output;

                //Executing the SQLCommand
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();


                if (success.Value.ToString().Equals("1"))
                {
                    //To send response data to the client side (HTML)
                    Response.Write("Logged in successfully");
                    Session["currentuser"] = username;
                    

                    /*ASP.NET session state enables you to store and retrieve values for a user
                    as the user navigates ASP.NET pages in a Web application.
                    This is how we store a value in the session*/
                  



                    if (type.Value.ToString().Equals("0"))
                    {
                        
                        Response.Redirect("customer1.aspx");
                    }


                    else if (type.Value.ToString().Equals("1"))
                    {


                        Response.Redirect("vendor.aspx");

                    }

                    else if (type.Value.ToString().Equals("2"))
                    {
                        Response.Redirect("Admin.aspx");

                    }

                    else
                    {
                        Response.Write("Delivery Personnel");

                    }

                }



                else
                {
                    Response.Write("Invalid username or password!");
                }
            }

        }
    }
}