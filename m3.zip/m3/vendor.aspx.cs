﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class vendor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void postProduct(object sender, EventArgs e)
        {
            Response.Redirect("postproduct.aspx");
        }

        protected void vendorviewProduct(object sender, EventArgs e)
        {
            Response.Redirect("vendorviewProduct.aspx");
        }

        protected void addOffer(object sender, EventArgs e)
        {
            Response.Redirect("offer.aspx");
        }

        protected void applyOffer(object sender, EventArgs e)
        {
            Response.Redirect("offerapply.aspx");
        }

        protected void remove(object sender, EventArgs e)
        {
            Label1.Visible = true;
            eoffer.Visible = true;
            Button8.Visible = true;
        }

        protected void checkandremoveExpiredoffer(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("checkandremoveExpiredoffer", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            try
            {
                int offerid = int.Parse(eoffer.Text);
                // string vendorname = (string)(Session["currentuser"]);

                cmd.Parameters.Add(new SqlParameter("@offerid", (int)offerid));
                //Save the output from the procedure

                conn.Open();
                int a = cmd.ExecuteNonQuery();
                conn.Close();


                if (a <= 0)
                {
                    Response.Write("You  are trying to remove something that doesn't exist Or not expired");
                }
                else
                {
                    Response.Write("Removed successfully");
                }

            }
            catch
            {
                Response.Write("unsuccessfull");

            }
        }
    }
}