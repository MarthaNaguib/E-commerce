﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace m3
{
    public partial class offer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addOffer(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("addOffer", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //To read the input from the user

            string offeramount = oamount.Text;
            string tt = oexpiry.Text;


            try
            {
                if (string.IsNullOrWhiteSpace(tt) || string.IsNullOrWhiteSpace(offeramount))
                {
                    Response.Write("Please re-enter all of the input");

                }
                else
                {
                    DateTime expirydate = new DateTime();
                    expirydate = DateTime.Parse(tt);

                    //pass parameters to the stored procedure

                    cmd.Parameters.Add(new SqlParameter("@offeramount", offeramount));
                    cmd.Parameters.Add(new SqlParameter("@expiry_date", expirydate));

                    //Executing the SQLCommand
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("Successfully Posted!");
                }
            }
            catch
            {
                Response.Write(" unsuccessful !");

            }
        }


    }
}