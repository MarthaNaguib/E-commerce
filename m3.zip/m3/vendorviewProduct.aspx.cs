﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace m3
{
    public partial class viewProduct : System.Web.UI.Page
    {
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        StringBuilder htmlTable = new StringBuilder();
        //create a new connection


        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        // SqlCommand cmd = new SqlCommand("customerRegister", conn);
        //cmd.CommandType = System.Data.CommandType.StoredProcedure;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                BindData();

        }

        private void BindData()
        {

            string connStr = ConfigurationManager.ConnectionStrings["milestone3"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("vendorviewProducts", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            string vendorname = (string)(Session["currentuser"]);
            cmd.Parameters.Add(new SqlParameter("@vendorname", vendorname));


            da = new SqlDataAdapter(cmd);
            da.Fill(ds);


            htmlTable.Append("<table border='1'>");
            htmlTable.Append("<tr style='background-color:green; color: White;'><th>serial_no</th><th>product_name</th><th>category</th><th>product_description</th><th>price</th><th>final_price</th><th>color</th><th>available</th><th>rate</th><th>vendor_username</th><th>customer_username</th><th>customer_order_id</th></tr>");

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            if (!object.Equals(ds.Tables[0], null))
            {
                if (ds.Tables[0].Rows.Count > 0)
                {

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        htmlTable.Append("<tr style='color: Black;'>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["serial_no"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["product_name"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["category"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["product_description"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["price"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["final_price"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["color"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["available"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["rate"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["vendor_username"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["customer_username"] + "</td>");
                        htmlTable.Append("<td>" + ds.Tables[0].Rows[i]["customer_order_id"] + "</td>");
                        htmlTable.Append("</tr>");
                    }
                    htmlTable.Append("</table>");
                    viewvendorproduct.Controls.Add(new Literal { Text = htmlTable.ToString() });
                }
                else
                {
                    htmlTable.Append("<tr>");
                    htmlTable.Append("<td align='center' colspan='4'>There is no Record.</td>");
                    htmlTable.Append("</tr>");
                    Response.Write("There is no Record");
                    Button1.Visible = false;
                }
            }


        }

        protected void EditProduct(object sender, EventArgs e)
        {

            Response.Redirect("EditProducts.aspx");

        }
    }
}